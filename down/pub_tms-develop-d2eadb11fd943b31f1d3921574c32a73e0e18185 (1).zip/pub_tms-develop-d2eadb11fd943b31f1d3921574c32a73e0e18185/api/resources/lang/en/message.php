<?php

return [
	
	'login_failed'=>'Invalid Username or Password.'
];