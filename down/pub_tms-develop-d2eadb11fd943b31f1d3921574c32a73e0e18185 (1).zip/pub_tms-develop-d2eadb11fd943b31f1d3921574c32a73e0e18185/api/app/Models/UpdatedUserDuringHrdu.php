<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UpdatedUserDuringHrdu extends Model
{
    //
    protected $table = 'updated_user_during_hrdu';    
}