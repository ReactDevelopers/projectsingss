export default class department{

	id: number;
	name: string;
	// created_at: Date | null;
	// updated_at: Date | null;
}