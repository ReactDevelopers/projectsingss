export const API_URL = process.env.API_URL;
//export const BASE_PATH = '/tms/client/build';
//export const BASE_URL = 'http://127.1.1.1';

export const BASE_PATH = process.env.BASE_PATH;
export const BASE_URL = process.env.BASE_URL;
export const ASSETS_URL = process.env.ASSETS_URL;